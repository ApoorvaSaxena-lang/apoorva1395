var emailValidator = RegExp(
    r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
var phoneValidator = RegExp(r'(^(?:[+0]9)?[0-9]{10}$)');
var passwordValidator =
    RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
var nameValidator = RegExp('[a-zA-Z]');
